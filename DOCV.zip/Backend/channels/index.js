import handleCustomerChannels from "./customer.js";
import handleTowerChannels from "./tower.js";
import handleServiceChannels from "./service.js";

export { handleCustomerChannels, handleTowerChannels, handleServiceChannels };
