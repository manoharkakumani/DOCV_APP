import { Customer, Auth } from "../models/index.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

import { stripe } from "../utils/constants.js";

const SALT_ROUNDS = 10;
const JWT_SECRET = process.env.JWT_SECRET;

export const addCustomer = async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password || !phone) {
      return res
        .status(400)
        .json({ error: "Name, email, password and phone are required" });
    }

    const cleanEmail = email.trim().toLowerCase();

    const findCustomer = await Customer.findOne({ email });
    if (findCustomer) {
      return res.status(400).json({ error: "Customer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const stripeCustomer = await stripe.customers.create({
      email: cleanEmail,
      name,
    });

    // console.log("Stripe customer:", stripeCustomer);

    const customer = new Customer({
      name,
      email,
      phone,
      stripeId: stripeCustomer.id,
    });
    await customer.save();

    const auth = new Auth({
      userId: customer._id,
      type: "Customer",
      email,
      password: hashedPassword,
    });
    await auth.save();
    const token = jwt.sign({ id: customer._id }, JWT_SECRET, {
      expiresIn: "1h",
    });
    customer.token = token;
    res.status(201).json(customer);
  } catch (err) {
    console.log("Error during customer creation:", err);
    res.status(400).json({ error: err.message });
  }
};

export const signCustomer = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: "Email and password are required" });
    }

    const auth = await Auth.findOne({ email, type: "Customer" });
    if (!auth) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    const isMatch = await bcrypt.compare(password, auth.password);
    if (!isMatch) {
      return res.status(400).json({ error: "Invalid email or password" });
    }

    // // check if email is verified
    // if (!auth.isVerified) {
    //   return res.status(400).json({ error: "Email not verified" });
    // }

    const customer = await Customer.findById(auth.userId);
    if (!customer) {
      return res.status(400).json({ error: "Customer not found" });
    }
    customer.token = jwt.sign({ id: customer._id }, JWT_SECRET, {
      expiresIn: "1h",
    });
    res.status(200).json(customer);
  } catch (err) {
    console.log("Error during customer creation:", err);

    res.status(400).json({ error: err.message });
  }
};

export const getCustomers = async (req, res) => {
  try {
    const customers = await Customer.find().populate("vehicles");
    res.status(200).json(customers);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

export const getCustomerById = async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id).populate(
      "vehicles"
    );
    if (!customer) return res.status(404).json({ error: "Customer not found" });
    res.status(200).json(customer);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

export const updateCustomer = async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;

    const auth = await Auth.findOne({ userId: req.params.id });
    if (!auth) {
      return res.status(404).json({ error: "User not found" });
    }

    if (password) {
      auth.password = await bcrypt.hash(password, SALT_ROUNDS);
      await auth.save();
    }

    if (email) {
      const cleanEmail = email.trim().toLowerCase();
      auth.email = cleanEmail;
      await auth.save();
    }

    const updatedFields = {};
    if (name) updatedFields.name = name;
    else if (email) updatedFields.email = email;
    else if (phone) updatedFields.phone = phone;

    const customer = await Customer.findByIdAndUpdate(
      req.params.id,
      updatedFields,
      { new: true, runValidators: true }
    );

    if (!customer) return res.status(404).json({ error: "Customer not found" });

    const customerResponse = customer.toObject();
    res.status(200).json(customerResponse);
  } catch (err) {
    if (err.name === "ValidationError") {
      const errors = Object.values(err.errors).map((error) => error.message);
      return res.status(400).json({ error: errors });
    }
    res
      .status(500)
      .json({ error: "An error occurred while updating the profile" });
  }
};

export const deleteCustomer = async (req, res) => {
  try {
    const customer = await Customer.findByIdAndDelete(req.params.id);
    if (!customer) return res.status(404).json({ error: "Customer not found" });
    res.status(200).json({ message: "Customer deleted successfully" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};
