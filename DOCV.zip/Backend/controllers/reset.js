import Auth from "../models/auth.js";
import bcrypt from "bcrypt";
import { generateOTP, sendEmail } from "../utils/constants.js";
const SALT_ROUNDS = 10;

// forgotPassword

export const forgotPassword = async (req, res) => {
  try {
    const { email, type } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }

    const auth = await Auth.findOne({ email, type });
    if (!auth) {
      return res.status(400).json({ error: "User not found" });
    }
    // Generate OTP and send to email
    const otp = generateOTP();

    await Auth.findByIdAndUpdate(auth._id, {
      otp,
    });

    // sendemail
    const { data, error } = await sendEmail(
      auth.email,
      "Reset Password OTP",
      `
          <h2> Your Confirmation code </h2>
          <h1>${otp}</h1>
        `
    );
    if (error) {
      return console.error({ error });
    }
    res.status(200).json({ message: "otp sent" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// otpVerification

export const otpVerification = async (req, res) => {
  const { email, otp, type } = req.body;

  console.log("otpVerification", email, otp, type);

  if (!email) {
    return res.status(400).json({ error: "Something went wrong" });
  }

  if (!otp) {
    return res.status(400).json({ error: "OTP are required" });
  }
  const auth = await Auth.findOne({ email, type });
  if (!auth) {
    return res.status(400).json({ error: "User not found" });
  }
  if (auth.otp.toString() !== otp) {
    return res.status(400).json({ error: "Invalid OTP" });
  }
  res.status(200).json({ message: "OTP verified" });
};

// resetPassword

export const resetPassword = async (req, res) => {
  const { email, password, type } = req.body;

  if (!email) {
    return res.status(400).json({ error: "Something went wrong" });
  }

  if (!password) {
    return res.status(400).json({ error: "password are required" });
  }
  const auth = await Auth.findOne({ email, type });
  if (!auth) {
    return res.status(400).json({ error: "User not found" });
  }

  const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

  await Auth.findByIdAndUpdate(auth._id, {
    password: hashedPassword,
  });

  res.status(200).json({ message: "Password reset successfully" });
};

export const resendOTP = async (req, res) => {
  try {
    const { email, type } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Something went wrong" });
    }

    const auth = await Auth.findOne({ email, type });
    if (!auth) {
      return res.status(400).json({ error: "User not found" });
    }
    // Generate OTP and send to email
    const otp = generateOTP();

    await Auth.findByIdAndUpdate(auth._id, {
      otp,
    });

    // sendemail
    const { data, error } = await sendEmail(
      auth.email,
      "Reset Password OTP",
      `
          <h2> Your Confirmation code </h2>
          <h1>${otp}</h1>
        `
    );
    if (error) {
      return console.error({ error });
    }
    res.status(200).json({ message: "otp sent" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// verifyEmail

// export const verifyEmail = async (req, res) => {
//   const { email } = req.body;

//   if (!email) {
//     return res.status(400).json({ error: "Email is required" });
//   }

//   const auth = await Auth.findOne({ email, type: "Customer" });
//   if (!auth) {
//     return res.status(400).json({ error: "Customer not found" });
//   }
//   const otp = generateOTP();
//   await Auth.findByIdAndUpdate(auth._id, {
//     otp,
//   });
//   // sendemail
//   const { data, error } = await sendEmail(
//     auth.email,
//     "Email Verification OTP",
//     `
//         <h2> Your Confirmation code </h2>
//         <h1>${otp}</h1>
//       `
//   );
//   if (error) {
//     return console.error({ error });
//   }
//   res.status(200).json({ message: "otp sent" });
// };
