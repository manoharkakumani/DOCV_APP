export const logger = async (req, res, next) => {
  const timestamp = new Date().toLocaleString();
  const method = req.method;
  const path = req.originalUrl || req.url;
  const query = JSON.stringify(req.query);

  // Capture the response status code
  const oldJson = res.json;
  res.json = function (body) {
    console.log(
      `[${timestamp}] ${method} ${path} - Status: ${res.statusCode} - Query: ${query}`
    );
    oldJson.call(this, body);
  };

  next();
};
