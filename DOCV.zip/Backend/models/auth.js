import mongoose from "mongoose";

const AuthSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
  },
  type: {
    enum: ["Customer", "Service", "Tower"],
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },

  otp: { type: Number },
});

const Auth = mongoose.model("Auth", AuthSchema);

export default Auth;
