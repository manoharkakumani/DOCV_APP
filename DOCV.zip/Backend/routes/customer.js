import express from "express";
import { CustomerController, ResetController } from "../controllers/index.js";

const customerRoutes = express.Router();

customerRoutes.post("/signup", CustomerController.addCustomer);
customerRoutes.post("/signin", CustomerController.signCustomer);
customerRoutes.get("/", CustomerController.getCustomers);
customerRoutes.get("/:id", CustomerController.getCustomerById);
customerRoutes.put("/:id", CustomerController.updateCustomer);
customerRoutes.delete("/:id", CustomerController.deleteCustomer);
// rest password reset routes

// customerRoutes.post("/verify-email", ResetController.verifyEmail);
customerRoutes.post("/forgot-password", ResetController.forgotPassword);
customerRoutes.post("/otp-verification", ResetController.otpVerification);
customerRoutes.post("/reset-password", ResetController.resetPassword);
customerRoutes.post("/resend-otp", ResetController.resendOTP);

export default customerRoutes;
