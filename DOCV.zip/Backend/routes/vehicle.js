import express from "express";
import { VehicleController } from "../controllers/index.js";

const vehicleRoutes = express.Router();

vehicleRoutes.post("/", VehicleController.addVehicle);
vehicleRoutes.get("/", VehicleController.getVehicles);
vehicleRoutes.get("/:id", VehicleController.getVehicleById);
vehicleRoutes.get("/user/:id", VehicleController.getVehiclesByUserId);
vehicleRoutes.put("/:id", VehicleController.updateVehicle);
vehicleRoutes.delete("/:id", VehicleController.deleteVehicle);

export default vehicleRoutes;
