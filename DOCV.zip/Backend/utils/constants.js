import Stripe from "stripe";
import { Resend } from "resend";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// 4 digit OTP generator
export const generateOTP = () => {
  return Math.floor(1000 + Math.random() * 9000);
};

// Send OTP to email using resend

const resend = new Resend(process.env.RESEND_SECRET_KEY);

export const sendEmail = async (email, subject, body) => {
  const { data, error } = await resend.emails.send({
    from: "DOCV <noreply@docv.site>",
    to: [email],
    subject: subject,
    html: body,
  });

  return { data, error };
};
