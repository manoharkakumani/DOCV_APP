export const ChatButton = ({ onClick }) => {
  return (
    <button
      onClick={onClick}
      className="relative inline-flex items-center gap-2 px-4 py-2 overflow-hidden rounded-full bg-gradient-to-r from-blue-500 to-blue-600 text-sm font-semibold text-white transition-all duration-300 hover:from-blue-600 hover:to-blue-700 hover:-translate-y-0.5 active:translate-y-0 group"
    >
      {/* Chat Icon */}
      <svg
        viewBox="0 0 24 24"
        className="w-4 h-4 transition-transform duration-300 group-hover:scale-110"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
      </svg>

      {/* Button Text with Animated Underline */}
      <span className="relative">
        Open Chat
        <span className="absolute bottom-0 left-0 w-full h-0.5 bg-white transform origin-left scale-x-0 transition-transform duration-300 group-hover:scale-x-100" />
      </span>

      {/* Hover Overlay */}
      <div className="absolute inset-0 w-full h-full bg-white/20 opacity-0 transition-opacity duration-300 group-hover:opacity-100 rounded-full" />
    </button>
  );
};
