import React, { useEffect } from "react";

const NotFound = () => {
  useEffect(() => {
    // Add animation class after component mounts
    const numbers = document.querySelectorAll(".animate-number");
    numbers.forEach((num, i) => {
      setTimeout(() => {
        num.classList.add("animate-bounce");
      }, i * 200);
    });
  }, []);

  const goBack = () => {
    window.history.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center px-6">
      <div className="text-center">
        {/* Animated 404 Numbers */}
        <div className="flex justify-center mb-8 space-x-4 text-8xl font-bold text-gray-900">
          <span className="animate-number transition-all duration-500 hover:text-blue-600 cursor-default">
            4
          </span>
          <span className="animate-number transition-all duration-500 hover:text-blue-600 cursor-default">
            0
          </span>
          <span className="animate-number transition-all duration-500 hover:text-blue-600 cursor-default">
            4
          </span>
        </div>

        {/* Floating Shapes Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-4 h-4 bg-blue-500 rounded-full opacity-20 animate-ping"></div>
          <div className="absolute top-1/3 right-1/3 w-6 h-6 bg-purple-500 rounded opacity-20 animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-8 h-8 bg-pink-500 rotate-45 opacity-20 animate-bounce"></div>
        </div>

        {/* Content */}
        <div className="relative">
          <h1 className="text-4xl font-bold text-gray-900 mb-4 animate-fade-in">
            Oops! Page Not Found
          </h1>
          <p className="text-gray-600 mb-8 max-w-md mx-auto animate-fade-in-up">
            The page you're looking for seems to have wandered off into the
            digital wilderness. Let's get you back on track!
          </p>

          {/* Back Button */}
          <button
            onClick={goBack}
            className="group relative inline-flex items-center px-8 py-3 text-lg font-medium text-white bg-blue-600 rounded-full overflow-hidden transition-all duration-300 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            {/* Button Background Animation */}
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-blue-500 to-blue-600 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>

            <span className="relative">Go Back</span>
          </button>
        </div>

        {/* Bottom Decoration */}
        <div className="mt-16 flex justify-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce delay-100"></div>
          <div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce delay-200"></div>
          <div className="w-2 h-2 rounded-full bg-pink-500 animate-bounce delay-300"></div>
        </div>
      </div>
    </div>
  );
};

// Add keyframe animations
const style = document.createElement("style");
style.textContent = `
  @keyframes blob {
    0% {
      transform: translate(0px, 0px) scale(1);
    }
    33% {
      transform: translate(30px, -50px) scale(1.1);
    }
    66% {
      transform: translate(-20px, 20px) scale(0.9);
    }
    100% {
      transform: translate(0px, 0px) scale(1);
    }
  }
  .animate-blob {
    animation: blob 7s infinite;
  }
  .animation-delay-2000 {
    animation-delay: 2s;
  }
  .animation-delay-4000 {
    animation-delay: 4s;
  }
  .animate-fade-in {
    animation: fadeIn 0.5s ease-in;
  }
  .animate-fade-in-up {
    animation: fadeInUp 0.5s ease-out;
  }
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
`;
document.head.appendChild(style);

export default NotFound;
