import Dashboard from "./Dashboard";
import SignIn from "./Signin";
import SignUp from "./Signup";
import BookingView from "./BookingView";
import Profile from "./Profile";
import BookingSettings from "./BookingSettings";
import Bookings from "./Bookings";
import Chat from "./Chat";
import OTPVerification from "./OTPVerification";
import ForgotPassword from "./ForgotPassword";
import PasswordReset from "./PasswordReset";
import NotFound from "./NotFound";

export {
  Dashboard,
  SignIn,
  SignUp,
  BookingView,
  Profile,
  BookingSettings,
  Bookings,
  Chat,
  ForgotPassword,
  OTPVerification,
  PasswordReset,
  NotFound,
};
