// SignIn.js
import React, { useEffect, useState } from "react";
import { View, StyleSheet } from "react-native";
import { Text, TextInput, Button } from "react-native-paper";
import { useUserContext } from "@/context/UserContext";
import Theme from "@/styles/Theme";

import { router } from "expo-router";

import { forgotPassword } from "@/utils/api";

const ForgotPassword = () => {
  const { user, SetUser } = useUserContext();
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");

  useEffect(() => {
    if (user) {
      router.replace("/home");
      return;
    }
  }, [user]);

  const validate = () => {
    let isValid = true;
    if (email === "") {
      setEmailError("Email is required");
      isValid = false;
    } else {
      setEmailError("");
    }
    return isValid;
  };

  const handleSendEmail = async () => {
    if (!validate()) return;

    try {
      const res = await forgotPassword({ email, type: "Tower" });
      if (res.status === 200) {
        router.push({
          pathname: "/otp-verification",
          params: { email },
        });
      } else {
        setEmailError(res.data.error);
      }
    } catch (error) {
      setEmailError(error.message);
    }
  };

  return (
    <View style={styles.container}>
      <View style={{ alignItems: "center" }}>
        <Text
          style={{
            color: Theme.colors.primary,
            fontSize: 32,
            fontWeight: "bold",
            marginBottom: 16,
          }}
        >
          Forgot Password
        </Text>
      </View>
      <View style={styles.inputContainer}>
        <TextInput
          label="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.input}
          textColor={Theme.colors.primary}
          theme={{
            colors: {
              onSurfaceVariant: Theme.colors.primary,
              primary: Theme.colors.primary,
            },
          }}
        />
        {emailError && <Text style={styles.errorText}>{emailError}</Text>}
      </View>
      <Button
        mode="contained"
        onPress={handleSendEmail}
        style={styles.button}
        labelStyle={styles.buttonLabel}
        textColor={Theme.colors.primary}
        theme={{
          colors: {
            onSurfaceVariant: Theme.colors.primary,
            primary: Theme.colors.primary,
          },
        }}
      >
        Send Email
      </Button>
      <Button
        onPress={() => router.push("/signin")}
        style={styles.button2}
        labelStyle={styles.buttonLabel2}
      >
        Back to Sign In
      </Button>
      <Button
        onPress={() => router.push("/signup")}
        style={styles.button2}
        labelStyle={styles.buttonLabel2}
      >
        Don't have an account? Sign Up
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Theme.colors.light,
    flex: 1,
    justifyContent: "center",
    padding: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  input: {
    backgroundColor: Theme.colors.light,
  },
  errorText: {
    color: Theme.colors.danger,
    marginBottom: 8,
  },
  button: {
    backgroundColor: Theme.colors.primary,
    marginTop: 16,
  },
  buttonLabel: {
    color: Theme.colors.white,
    fontSize: 16,
  },
  button2: {
    marginTop: 16,
  },
  buttonLabel2: {
    color: Theme.colors.primary,
    fontSize: 16,
  },
});

export default ForgotPassword;
