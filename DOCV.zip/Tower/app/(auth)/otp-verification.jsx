// OTPVerification.js
import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import Theme from "@/styles/Theme";

import { otpVerification, resendOTP } from "@/utils/api";

import { useLocalSearchParams, router } from "expo-router";

const OTPVerification = () => {
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [error, setError] = useState("");
  const inputs = useRef([]);

  const { email } = useLocalSearchParams();
  const focusNext = (index, value) => {
    if (value && index < 3) {
      inputs.current[index + 1].focus();
    }
  };

  const focusPrev = (index) => {
    if (index > 0) {
      inputs.current[index - 1].focus();
    }
  };

  const handleOtpChange = (value, index) => {
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setError("");
    focusNext(index, value);
  };

  const handleResendOTP = async () => {
    try {
      const res = await resendOTP({ email, type: "Tower" });
      if (res.status === 200) {
        Alert.alert("OTP Resent", "Please check your email for the new OTP");
      } else {
        setError(res.data.error);
      }
    } catch (error) {
      setError(error.message);
    }
  };

  const handleVerifyOTP = async () => {
    const otpString = otp.join("");
    if (otpString.length === 4) {
      try {
        const res = await otpVerification({
          email,
          otp: otpString,
          type: "Tower",
        });
        if (res.status === 200) {
          router.push({
            pathname: "/reset-password",
            params: { email },
          });
        } else {
          setError(res.data.error);
        }
      } catch (error) {
        setError(error.message);
      }
    } else {
      setError("Please enter a valid OTP");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter Verification Code</Text>
      <Text style={styles.subtitle}>
        We have sent a verification code to your email
      </Text>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      <View style={styles.otpContainer}>
        {otp.map((digit, index) => (
          <TextInput
            key={index}
            ref={(ref) => (inputs.current[index] = ref)}
            style={styles.otpInput}
            maxLength={1}
            keyboardType="numeric"
            value={digit}
            onChangeText={(value) => handleOtpChange(value, index)}
            onKeyPress={({ nativeEvent }) => {
              if (nativeEvent.key === "Backspace" && !digit) {
                focusPrev(index);
              }
            }}
          />
        ))}
      </View>

      <TouchableOpacity style={styles.button} onPress={handleVerifyOTP}>
        <Text style={styles.buttonLabel}>Verify OTP</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button2} onPress={handleResendOTP}>
        <Text style={styles.buttonLabel2}>Resend OTP</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Theme.colors.light,
    flex: 1,
    justifyContent: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 8,
    textAlign: "center",
    color: Theme.colors.primary,
  },
  subtitle: {
    fontSize: 16,
    color: Theme.colors.gray2,
    marginBottom: 24,
    textAlign: "center",
  },
  otpContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
    paddingHorizontal: 20,
  },
  otpInput: {
    backgroundColor: Theme.colors.light,
    width: 50,
    height: 50,
    borderWidth: 1,
    borderColor: Theme.colors.primary,
    borderRadius: 8,
    textAlign: "center",
    fontSize: 20,
  },
  errorText: {
    color: Theme.colors.danger,
    marginBottom: 8,
    textAlign: "center",
  },
  button: {
    backgroundColor: Theme.colors.primary,
    marginTop: 16,
    padding: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonLabel: {
    color: Theme.colors.white,
    fontSize: 16,
  },
  button2: {
    marginTop: 16,
  },
  buttonLabel2: {
    color: Theme.colors.white,
    fontSize: 16,
    textAlign: "center",
    backgroundColor: Theme.colors.secondary,
    padding: 16,
    borderRadius: 8,
  },
});

export default OTPVerification;
