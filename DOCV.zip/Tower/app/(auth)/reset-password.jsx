// ResetPassword.js
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import Theme from "@/styles/Theme";
import { useLocalSearchParams, router } from "expo-router";
import { resetPassword } from "@/utils/api";

const ResetPassword = () => {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const { email } = useLocalSearchParams();

  const handleResetPassword = async () => {
    // Validate passwords min 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character
    if (newPassword.length < 8) {
      setError("Password must be at least 8 characters long");
      return;
    } else if (!/[A-Z]/.test(newPassword)) {
      setError("Password must contain at least 1 uppercase letter");
      return;
    } else if (!/[a-z]/.test(newPassword)) {
      setError("Password must contain at least 1 lowercase letter");
      return;
    } else if (!/[0-9]/.test(newPassword)) {
      setError("Password must contain at least 1 number");
      return;
    } else if (!/[!@#$%^&*]/.test(newPassword)) {
      setError("Password must contain at least 1 special character");
      return;
    } else if (newPassword !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    const data = { email, password: newPassword, type: "Tower" };
    try {
      const res = await resetPassword(data);
      if (res.status === 200) {
        router.replace("/signin");
      } else {
        setError(res.data.error);
      }
    } catch (error) {
      setError(error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reset Password</Text>
      <Text style={styles.subtitle}>Enter your new password below</Text>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      <View style={styles.inputContainer}>
        <TextInput
          style={[styles.input, styles.inputField]}
          placeholder="New Password"
          secureTextEntry
          value={newPassword}
          onChangeText={(text) => {
            setNewPassword(text);
            setError("");
          }}
        />
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          style={[styles.input, styles.inputField]}
          placeholder="Confirm Password"
          secureTextEntry
          value={confirmPassword}
          onChangeText={(text) => {
            setConfirmPassword(text);
            setError("");
          }}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleResetPassword}>
        <Text style={styles.buttonLabel}>Reset Password</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: Theme.colors.light,
    flex: 1,
    justifyContent: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 8,
    textAlign: "center",
    color: Theme.colors.primary,
  },
  subtitle: {
    fontSize: 16,
    color: Theme.colors.gray2,
    marginBottom: 24,
    textAlign: "center",
  },
  inputContainer: {
    marginBottom: 16,
  },
  input: {
    backgroundColor: Theme.colors.light,
  },
  inputField: {
    borderWidth: 1,
    borderColor: Theme.colors.primary,
    borderRadius: 8,
    padding: 12,
    color: Theme.colors.primary,
    fontSize: 16,
  },
  errorText: {
    color: Theme.colors.danger,
    marginBottom: 8,
    textAlign: "center",
  },
  button: {
    backgroundColor: Theme.colors.primary,
    marginTop: 16,
    padding: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonLabel: {
    color: Theme.colors.white,
    fontSize: 16,
  },
});

export default ResetPassword;
