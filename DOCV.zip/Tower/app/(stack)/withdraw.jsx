import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import { TextInput, Button, Snackbar } from "react-native-paper";
import { useUserContext } from "@/context/UserContext";
import { withdrawEarnings } from "@/utils/api";

import { router, useLocalSearchParams } from "expo-router";
import Theme from "@/styles/Theme";

const Withdraw = () => {
  const { balance: balanceString } = useLocalSearchParams();
  const balance = JSON.parse(balanceString);
  const { user } = useUserContext();
  const [amount, setAmount] = useState(String(balance)); // Set the initial value to the user's balance
  // const [paymentMethod, setPaymentMethod] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const handleWithdraw = async () => {
    setLoading(true);
    try {
      if (amount === "") {
        setError("Amount is required");
        return;
      } else if (parseInt(amount) > balance) {
        setError("Insufficient funds");
        return;
      }
      const response = await withdrawEarnings(user._id, amount);
      if (response.status === 200) {
        setSuccess(true);
      } else {
        setError("Failed to withdraw funds. Please try again later.");
      }
    } catch (error) {
      setError("Network error. Please check your internet connection.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) {
      router.push("/(auth)/signin");
    }
  }, [user]);

  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 20, marginBottom: 20, top: -100 }}>
        Amount to withdraw (max $ {balance})
      </Text>
      <View style={{ flexDirection: "row" }}>
        <Text style={{ fontSize: 45, marginRight: 10, top: -100 }}>$</Text>
        <TextInput
          value={amount}
          onChangeText={(text) => setAmount(text)}
          keyboardType="numeric"
          style={styles.input}
          textColor={Theme.colors.primary}
          placeholder="0.00"
          theme={{
            colors: {
              onSurfaceVariant: Theme.colors.primary,
              primary: Theme.colors.primary,
            },
          }}
        />
      </View>
      <Button
        mode="contained"
        onPress={handleWithdraw}
        loading={loading}
        disabled={loading}
        style={styles.button}
      >
        Withdraw
      </Button>
      <Snackbar
        visible={!!error}
        onDismiss={() => setError(null)}
        style={styles.snackbar}
        duration={Snackbar.DURATION_SHORT}
      >
        {error}
      </Snackbar>
      <Snackbar
        style={styles.snackbar}
        visible={success}
        onDismiss={() => {
          setSuccess(false);
          router.push("/earnings");
        }}
        duration={Snackbar.DURATION_SHORT}
      >
        Withdrawal successful!
      </Snackbar>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
    backgroundColor: Theme.colors.light,
  },
  input: {
    top: -100,
    marginBottom: 10,
    backgroundColor: Theme.colors.light,
    fontSize: 35,
    width: "75%",
  },
  button: {
    top: -100,
    marginTop: 20,
    backgroundColor: Theme.colors.primary,
    fontSize: 18,
  },
  snackbar: {
    backgroundColor: Theme.colors.primary,
  },
});

export default Withdraw;
