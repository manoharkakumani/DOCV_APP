export const GOOGLE_MAPS_APIKEY = "AIzaSyAkVeCDcNa4hosacelJvGyLLbAFNuRX9sM";
