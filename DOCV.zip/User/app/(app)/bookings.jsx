import { Bookings } from "@/components/";

export default function ActivityScreen() {
  return <Bookings type="future" />;
}
