import React, { useEffect, useState } from "react";
import { View, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import { TextInput, Avatar, Text, Snackbar } from "react-native-paper";
import * as ImagePicker from "expo-image-picker";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useUserContext } from "@/context/UserContext";
import { updateCustomer } from "@/utils/api"; // Assume this function exists
import Theme from "@/styles/Theme";

const ProfileEditScreen = () => {
  const { user, setUser } = useUserContext();

  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState(user.phone);
  const [avatar, setAvatar] = useState(require("@/assets/user.png"));

  const [editName, setEditName] = useState(false);
  const [editEmail, setEditEmail] = useState(false);
  const [editPhone, setEditPhone] = useState(false);
  const [editPassword, setEditPassword] = useState(false);

  const [snackbarVisible, setSnackbarVisible] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");

  useEffect(() => {
    if (!user) {
      router.replace("/(auth)/signin");
    }
  }, [user]);

  const showSnackbar = (message) => {
    setSnackbarMessage(message);
    setSnackbarVisible(true);
  };

  const handleUpdateField = async (field, value, setEditState) => {
    try {
      console.log(field, value);
      const response = await updateCustomer(user._id, {
        [field]: value,
      });
      if (response.status === 200) {
        setUser(response.data);
        setEditState(false);
        showSnackbar(
          `${
            field.charAt(0).toUpperCase() + field.slice(1)
          } updated successfully`
        );
      } else {
        showSnackbar(`Failed to update ${field}`);
      }
    } catch (error) {
      console.error(`Error updating ${field}:`, error);
      showSnackbar(`Error updating ${field}`);
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      const newAvatar = { uri: result.assets[0].uri };
      setAvatar(newAvatar);
      handleUpdateField("avatar", newAvatar, () => {});
    }
  };

  const renderEditableField = (
    label,
    value,
    setValue,
    editable,
    setEditable,
    icon,
    secureTextEntry = false
  ) => (
    <View style={styles.fieldContainer}>
      {editable ? (
        <TextInput
          label={label}
          value={value}
          onChangeText={setValue}
          mode="outlined"
          style={styles.input}
          secureTextEntry={secureTextEntry}
          left={
            <TextInput.Icon
              icon={() => (
                <MaterialCommunityIcons
                  name={icon}
                  size={24}
                  color={Theme.colors.primary}
                />
              )}
              size={24}
              color={Theme.colors.primary}
              style={styles.icon}
            />
          }
          right={
            <TextInput.Icon
              icon={() => (
                <View style={styles.iconContainer}>
                  <TouchableOpacity
                    onPress={() =>
                      handleUpdateField(label.toLowerCase(), value, setEditable)
                    }
                  >
                    <MaterialCommunityIcons
                      name="check"
                      size={24}
                      color={Theme.colors.primary}
                      style={styles.saveIcon}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setEditable(false);
                      setValue(user[label.toLowerCase()]);
                    }}
                  >
                    <MaterialCommunityIcons
                      name="close"
                      size={24}
                      color={Theme.colors.danger}
                      style={styles.cancleIcon}
                    />
                  </TouchableOpacity>
                </View>
              )}
            />
          }
        />
      ) : (
        <View style={styles.textContainer}>
          <MaterialCommunityIcons
            name={icon}
            size={24}
            color={Theme.colors.primary}
            style={styles.icon}
          />
          <Text style={styles.fieldText}>
            {secureTextEntry ? "••••••••" : value}
          </Text>
          <MaterialCommunityIcons
            name="pencil"
            size={24}
            color={Theme.colors.primary}
            style={styles.icon}
            onPress={() => setEditable(true)}
          />
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <TouchableOpacity onPress={pickImage} style={styles.avatarContainer}>
            <Avatar.Image size={120} source={avatar} />
            <View style={styles.editIconContainer}>
              <MaterialCommunityIcons name="camera" size={24} color="#fff" />
            </View>
          </TouchableOpacity>
        </View>
        <View style={styles.form}>
          {renderEditableField(
            "Name",
            name,
            setName,
            editName,
            setEditName,
            "account-outline"
          )}
          {renderEditableField(
            "Email",
            email,
            setEmail,
            editEmail,
            setEditEmail,
            "email-outline"
          )}
          {renderEditableField(
            "Phone",
            phone,
            setPhone,
            editPhone,
            setEditPhone,
            "phone-outline"
          )}
          {renderEditableField(
            "Password",
            password,
            setPassword,
            editPassword,
            setEditPassword,
            "lock-outline",
            true
          )}
        </View>
      </ScrollView>
      <Snackbar
        visible={snackbarVisible}
        onDismiss={() => setSnackbarVisible(false)}
        duration={3000}
        style={{ backgroundColor: Theme.colors.primary }}
      >
        {snackbarMessage}
      </Snackbar>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Theme.colors.light,
  },
  header: {
    alignItems: "center",
    paddingTop: 30,
    paddingBottom: 20,
    backgroundColor: Theme.colors.secondary,
  },
  avatarContainer: {
    position: "relative",
  },
  editIconContainer: {
    position: "absolute",
    right: 0,
    bottom: 0,
    backgroundColor: Theme.colors.primary,
    borderRadius: 20,
    padding: 8,
  },
  form: {
    padding: 20,
  },
  fieldContainer: {
    marginBottom: 16,
  },
  input: {
    backgroundColor: Theme.colors.white,
  },
  textContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Theme.colors.white,
    borderRadius: 4,
    padding: 10,
    height: 50,
  },
  icon: {
    marginRight: 10,
  },
  fieldText: {
    flex: 1,
    fontSize: 16,
  },
  iconContainer: {
    flexDirection: "row",
    padding: 8,

    justifyContent: "space-between",
  },
  saveIcon: {
    // marginRight: 10,
    // right: 20,
  },
  cancleIcon: {
    // left: 20,
  },
});

export default ProfileEditScreen;
