import axios from "axios";

export const apiurl = "https://backend.docv.site/api";
export const socketURL = "wss://backend.docv.site";

export const customerLogin = async (data) => {
  try {
    const res = await axios.post(`${apiurl}/customer/signin`, data);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const customerSignup = async (data) => {
  try {
    const res = await axios.post(
      `${apiurl}/customer/signup`,
      JSON.stringify(data),
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return res;
  } catch (error) {
    console.log(
      "Signup error:",
      error.response ? error.response.data : error.message
    );
    return error.response;
  }
};

export const getCustomer = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/customer/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error;
  }
};

export const updateCustomer = async (id, customer) => {
  try {
    const res = await axios.put(`${apiurl}/customer/${id}`, customer);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getCustomerVehicles = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/vehicle/user/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const addVehicle = async (vehicle) => {
  try {
    const res = await axios.post(`${apiurl}/vehicle`, vehicle);
    console.log("Add Vehicle response:", res);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getVehicle = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/vehicle/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const updateVehicle = async (id, vehicle) => {
  try {
    const res = await axios.put(`${apiurl}/vehicle/${id}`, vehicle);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const deleteVehicle = async (id) => {
  try {
    const res = await axios.delete(`${apiurl}/vehicle/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getCustomerBookings = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/customer/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getCustomerOngoingBookings = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/customer/ongoing/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};
export const getCustomerUpcomingBookings = async (id, date) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/customer/upcoming/${id}`, {
      params: { date },
    });
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};
export const getFutureBookingsByUserId = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/customer/future/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getCustomerPastBookings = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/customer/past/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const addBooking = async (booking) => {
  try {
    const res = await axios.post(`${apiurl}/bookings`, booking);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getBooking = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const updateBooking = async (id, booking) => {
  try {
    const res = await axios.put(`${apiurl}/bookings/${id}`, booking);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getVehicleBookings = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/bookings/vehicle/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const addTowingBooking = async (booking) => {
  try {
    const res = await axios.post(`${apiurl}/bookings/towing`, booking);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getChatMessages = async (chatId) => {
  try {
    const res = await axios.get(`${apiurl}/chat/${chatId}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const createPaymentIntent = async (data) => {
  try {
    const res = await axios.post(
      `${apiurl}/payment/payment-intent`,
      JSON.stringify(data),
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getPaymentMethods = async (customerId) => {
  try {
    const res = await axios.get(`${apiurl}/payment/${customerId}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const createSetupIntent = async (customerId) => {
  try {
    const res = await axios.get(`${apiurl}/payment/intent/${customerId}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const deletePaymentMethod = async (paymentMethodId) => {
  try {
    const res = await axios.delete(`${apiurl}/payment/${paymentMethodId}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const getNearbyServiceProviders = async (data) => {
  try {
    const response = await axios.post(
      `${apiurl}/service-provider/nearby`,
      data
    );
    return response;
  } catch (error) {
    console.error("Error in getNearbyServiceProviders:", error);
    throw error;
  }
};

// nearByTowers

export const getNearbyTowers = async (data) => {
  try {
    const response = await axios.post(
      `${apiurl}/service-provider/towers/nearby`,
      data
    );
    return response;
  } catch (error) {
    console.error("Error in getNearbyTowers:", error);
    throw error;
  }
};

export const getRide = async (id) => {
  try {
    const res = await axios.get(`${apiurl}/ride/${id}`);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

export const assignTower = async (bookingId) => {
  try {
    const data = { bookingId: bookingId };
    const res = await axios.post(
      `${apiurl}/service-provider/assign-tower/`,
      data
    );
    console.log("Assign Tower response:", res);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

//forgot password

export const forgotPassword = async (data) => {
  try {
    const res = await axios.post(`${apiurl}/customer/forgot-password/`, data);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

// otp verification
export const otpVerification = async (data) => {
  try {
    const res = await axios.post(`${apiurl}/customer/otp-verification/`, data);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

// resend otp
export const resendOTP = async (data) => {
  try {
    const res = await axios.post(`${apiurl}/customer/resend-otp/`, data);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};

// reset password
export const resetPassword = async (data) => {
  try {
    const res = await axios.post(`${apiurl}/customer/reset-password/`, data);
    return res;
  } catch (error) {
    console.log(error.response);
    return error.response;
  }
};
