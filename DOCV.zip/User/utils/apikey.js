export const GOOGLE_MAPS_APIKEY = "AIzaSyAkVeCDcNa4hosacelJvGyLLbAFNuRX9sM";

export const MAPS_APIKEY = "b8568cb9afc64fad861a69edbddb2658";
